#include <stdio.h>
#include <stdlib.h>


void retira (int *indicado,int a,int n) ;

int n,i,flag = 1;
int a,b;
int *indicado,*visitado,*relacionado;

int main()
{

    scanf("%d",&n);

    indicado = (int*)calloc(n,sizeof(int));

    visitado = (int*)calloc(n,sizeof(int));

    relacionado = (int*)calloc(n,sizeof(int));

    for (i = 0; i < n; i++)
    {
        scanf("%d %d",&a,&b);
        relacionado[a - 1] = b ;
        indicado[a - 1]++;
        indicado[b - 1]++;
        visitado[b - 1]++;
    }

    printf("\n\nRelacionado = ");
    for(i = 0; i < n; i++)
        printf("%d ",relacionado[i]);

    printf("\n\nIndicado = ");
    for(i = 0; i < n; i++)
        printf("%d ",indicado[i]);

    printf("\n\nVisitado = ");

    for(i = 0; i < n; i++)
        printf("%d ",visitado[i]);

    printf("\n");

    printf("\n-----------------\n");

    for (i = 0 ; i < n; i++)
    {
        if(visitado[i] == 0)
        {
            indicado[i]--;
            indicado[relacionado[i]-1]--;
        }
    }
//    do
//    {
//        flag = 0;
//        for (i = 0; i < n; i++)
//        {
//            if (indicado[i] == 1) //&& (indicado[i] > 0))
//            {
//                retira(matAdj,indicado,i,n);
//                flag = 1;
//            }
//        }
//    }
//    while (flag == 1);

    printf("\n-----------------\n");
    printf("\n\nRelacionado = ");
    for(i = 0; i < n; i++)
        printf("%d ",relacionado[i]);

    printf("\n\nIndicado = ");
    for(i = 0; i < n; i++)
        printf("%d ",indicado[i]);

    printf("\n\nVisitado = ");

    for(i = 0; i < n; i++)
        printf("%d ",visitado[i]);

    printf("\n");
    printf("\n-----------------\n");

    printf("\n");
    printf("\n");
    for (i = 0; i < n; i++)
    {
        if (indicado[i] > 1)
        {
            printf("%d ",i+1);
        }
    }
}

//void retira (int **mat,int *indicado,int a,int n) {
//    int i;
//    for (i = 0;i < n;i++) {
//        if (matAdj[a][i] == 1) {
//            matAdj[a][i] = 0;
//            matAdj[i][a] = 0;
//            indicado[a] = 0;
//            indicado[i]--;
//        }
//    }
//}

