#include <stdio.h>
#include <stdlib.h>

int n,i,flag = 1;
int a,b;
int *par,*indicado,*indica;

int main()
{

    scanf("%d",&n);

    indica = (int*)calloc(n,sizeof(int)); //pessoa X indicou Y ---> indica[X]= Y

    par = (int*)calloc(n,sizeof(int)); //quantidade de par para X -->par[X] = qtd

    indicado = (int*)calloc(n,sizeof(int)); //quantidade de que X foi indicado -->indicado[X] = qtd


    for (i = 0; i < n; i++)
    {
        scanf("%d %d",&a,&b);
        indica[a - 1] = b ;
        par[a - 1]++;
        par[b - 1]++;
        indicado[b - 1]++;
    }

    for (i = 0 ; i < n; i++)
    {
        if(indicado[i] == 0)  //se a pessoa X  nao for indicado ...
        {
            par[i]== 0;            //decrementa qtd de par[X]
            par[indica[i]-1]--; //e tambem decrementa qtd de quem X indicou
        }
    }

    for (i = 0; i < n; i++)
        if (par[i] > 1)
            printf("%d ",i+1); //imprime pessoas que possuem par > 1
}

