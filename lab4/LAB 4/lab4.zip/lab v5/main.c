#include <stdio.h>
#include <stdlib.h>


void retira (int **mat,int *indicado,int a,int n) ;

int n,i,j,k ,cont,flag = 1;
int a,b;
int *indicado,**matAdj,*visitado,*aux;

int main()
{

    scanf("%d",&n);

    indicado = (int*)calloc(n,sizeof(int));

    visitado = (int*)calloc(n,sizeof(int));

    aux = (int*)calloc(n,sizeof(int));

    matAdj = (int **) calloc (n,sizeof(int *));
    for ( i = 0; i < n+1; i++ )
        matAdj[i] = (int*) calloc (n, sizeof(int));

    for (i = 0; i < n; i++)
    {
        scanf("%d %d",&a,&b);
        indicado[a - 1]++;
        indicado[b - 1]++;
        matAdj[a - 1][b - 1] = 1;
        matAdj[b - 1][a - 1] = 1;
    }

    printf("\n");

    for(i = 0; i < n;i++)
        printf("%d ",indicado[i]);

     printf("\n");

    for (i = 0; i < n; i++)
    {
        printf("\n");
        for(j = 0; j < n; j++)
            printf ("%d ",matAdj[i][j]);
    }

    printf("\n-----------------\n");
    do {
        flag = 0;
        for (i = 0;i < n;i++)
        {
            if (indicado[i] == 1) //&& (indicado[i] > 0))
                {
                retira(matAdj,indicado,i,n);
                flag = 1;
                }
        }
    }
    while (flag == 1);

     printf("\n-----------------\n");
     for(i = 0; i < n;i++)
        printf("%d ",indicado[i]);
    printf("\n-----------------\n");
     for (i = 0;i < n;i++) {
            printf("indicado[%d] = %d\n",i,indicado[i]);

    }
     printf("\n");
      printf("\n");
    for (i = 0;i < n;i++) {
        if (indicado[i] > 1) {
            printf("%d ",i+1);
        }
    }
}

void retira (int **mat,int *indicado,int a,int n) {
    int i;
    for (i = 0;i < n;i++) {
        if (matAdj[a][i] == 1) {
            matAdj[a][i] = 0;
            matAdj[i][a] = 0;
            indicado[a] = 0;
            indicado[i]--;
        }
    }
}

//#include<stdio.h>
//#include <stdlib.h>
//
//enum boolean {
//    true = 1, false = 0
//};
//typedef  enum boolean  bool;
//
//void retira (int **mat,int *vet,int a,int n) {
//    int i;
//    for (i=1;i<n+1;i++) {
//        if (mat[a][i] == 1) {
//            mat[a][i] = 0; // retira da lista de amizade na matriz.
//            mat[i][a] = 0; // retira da lista de amizade na matriz.
//            vet[a] = 0; //nao podera ir na festa entao nao "tera nenhum amigo"
//            vet[i]--; //retira 1 amigo de seus numero de amigos.
//        }
//    }
//}
//
//
//int main()
//{
//    int n,p,k,i,a,b,resultado=0;
//    bool continua = true;
//    scanf("%d %d %d",&n,&p,&k);
//    int *vet;
//    int **mat;
//
//    vet = (int *)calloc(n+1,sizeof(int));
//
//    mat = (int **) calloc (n+1, sizeof(int *));
//    if (mat == NULL) {
//        printf ("** Erro: Memoria Insuficiente **");
//        return (NULL);
//    }
//  /* aloca as colunas da matriz */
//    for ( i = 0; i < n+1; i++ ) {
//        mat[i] = (int*) calloc (n+1, sizeof(int));
//        if (mat[i] == NULL) {
//            printf ("** Erro: Memoria Insuficiente **");
//            return (NULL);
//        }
//    }
//
//    for (i=0 ; i < p ; i++) {
//        scanf("%d %d",&a,&b);
//        vet[a]++;
//        vet[b]++;
//        mat[a][b] = 1;
//        mat[b][a] = 1;
//    }
//
//    /*for (i=0;i<n+1;i++) {
//        printf("\n");
//        for(j=0;j<n+1;j++)
//            printf ("%d ",mat[i][j]);
//    }*/ //Preenchimento da matriz esta OK
//
//    while(continua) {
//        continua = false;
//        for (i=1;i<n+1;i++){
//            if (vet[i] < k && vet[i] > 0) { // Esse cara n�o pode ir para a festa e pode afetar outros que poderiam.
//                retira(mat,vet,i,n);//Entao se o cara nao vai pra festa logo remover todas as amizades dele e zerar o vetor de amizades.
//                continua = true;
//            }
//        }
//    }
//
//    for (i=1;i<n+1;i++) {
//        if (vet[i] >= k) {
//            resultado++;
//            printf("vet[%d] = %d\n",i,vet[i]);
//        }
//    }
//    printf("%d",resultado);
//
//    return 0;
//}
